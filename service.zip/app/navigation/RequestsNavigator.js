import React from "react";

import { createStackNavigator } from "@react-navigation/stack";
import ServiceRequestScreen from "../screens/ServiceRequestScreen";

import RequestDetailsScreen from "../screens/RequestDetailsScreen";
import CarDetailsScreen from "../screens/CarDetailsScreen";

const Stack = createStackNavigator();

function RequestsNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="MyRequests"
        component={ServiceRequestScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen name="Details" component={RequestDetailsScreen} />
      <Stack.Screen name="CarDetails" component={CarDetailsScreen} />
    </Stack.Navigator>
  );
}
export default RequestsNavigator;
