import React from "react";

import { createStackNavigator } from "@react-navigation/stack";

import RequestDetailsScreen from "../screens/RequestDetailsScreen";
import MyScheduleScreen from "../screens/MyScheduleScreen";
import CarDetailsScreen from "../screens/CarDetailsScreen";
import ScheduleDetailsScreen from "../screens/ScheduleDetailsScreen";

const Stack = createStackNavigator();

function ScheduleNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Schedule"
        component={MyScheduleScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen name="Details" component={ScheduleDetailsScreen} />
      <Stack.Screen name="CarDetails" component={CarDetailsScreen} />
    </Stack.Navigator>
  );
}
export default ScheduleNavigator;
