export default {
  primary: "#F2605",
  secondary: "#54900F",
  black: "#000",
  white: "#fff",
  medium: "#6e6969",
  light: "#e0db5a",
  dark: "#1F2605",
  backgroundColor: "#eef2e9",
  danger: "#ff5252",
  text: "#1e1f1a",
  brigthGreen: "#6fd22e",
};
