import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDDJZ2orv-uKDP5_ICZY4qxBBkL-J-BzS0",
  authDomain: "goautoservice-99a07.firebaseapp.com",
  projectId: "goautoservice-99a07",
  storageBucket: "goautoservice-99a07.appspot.com",
  messagingSenderId: "944489682703",
  appId: "1:944489682703:web:98035ce9d430229310d07a",
  measurementId: "G-DF7ZTXEFWV",
};

let app;

if (firebase.apps.length === 0) {
  app = firebase.initializeApp(firebaseConfig);
} else {
  app = firebase.app();
}

const db = app.firestore();
const auth = firebase.auth();

export { db, auth };
