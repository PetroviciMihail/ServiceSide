import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";
import {
  getStorage,
  ref,
  getDownloadURL,
  connectStorageEmulator,
} from "firebase/storage";
import {
  collection,
  query,
  where,
  getDocs,
  getDoc,
  setDoc,
  doc,
} from "firebase/firestore";
import { isFunction } from "formik";

const firebaseConfig = {
  apiKey: "AIzaSyDDJZ2orv-uKDP5_ICZY4qxBBkL-J-BzS0",
  authDomain: "goautoservice-99a07.firebaseapp.com",
  projectId: "goautoservice-99a07",
  storageBucket: "goautoservice-99a07.appspot.com",
  messagingSenderId: "944489682703",
  appId: "1:944489682703:web:98035ce9d430229310d07a",
  measurementId: "G-DF7ZTXEFWV",
};

let app;

if (firebase.apps.length === 0) {
  app = firebase.initializeApp(firebaseConfig);
} else {
  app = firebase.app();
}

var rad = function (x) {
  return (x * Math.PI) / 180;
};

var getDistance = function (p1, p2) {
  var R = 6378137; // Earth’s mean radius in meter
  var dLat = rad(p2.lat - p1.lat);
  var dLong = rad(p2.lng - p1.lng);
  var a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(rad(p1.lat)) *
      Math.cos(rad(p2.lat)) *
      Math.sin(dLong / 2) *
      Math.sin(dLong / 2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  var d = R * c;
  return d; // returns the distance in meter
};

const getRequests = async (service, distancee, category) => {
  const details = await getAccountDetails(auth.currentUser.email);

  const q = query(collection(db, "ServiceRequests"));

  var newdata = [];
  const querySnapshot = await getDocs(q);

  for (const doc of querySnapshot.docs) {
    var itemdata = doc.data();
    //calculate distance from the service
    var requestCoords = { lng: itemdata.lng, lat: itemdata.lat };
    var serviceCoords = { lng: details[0].lng, lat: details[0].lat };
    var distance = getDistance(requestCoords, serviceCoords);
    itemdata.distance = distance / 1000;
    console.log(itemdata);
    console.log(distancee);
    if (itemdata.services.indexOf(service) === -1) {
      if (itemdata.distance <= distancee && itemdata.scheduled === false) {
        console.log(category + " ? " + itemdata.category);
        if (category == "" || category == itemdata.category)
          newdata = [...newdata, itemdata];
      }
    }
  }
  console.log("log din firebase api");
  console.log(newdata);
  return newdata;
};

const getRequestOffers = async (owner, docName) => {
  const q = query(collection(db, "Offers", owner, docName));
  var newdata = [];
  const querySnapshot = await getDocs(q);
  for (const doc of querySnapshot.docs) {
    var itemdata = doc.data();
    newdata = [...newdata, itemdata];
  }
  console.log("log din firebase api request details");
  console.log(newdata);
  return newdata;
};

const getAccountDetails = async (owner) => {
  const q = query(
    collection(db, "ServiceAccountsDetails"),
    where("owner", "==", owner)
  );

  var newdata = [];
  const querySnapshot = await getDocs(q);

  for (const doc of querySnapshot.docs) {
    var itemdata = doc.data();

    newdata = [...newdata, itemdata];
  }
  console.log("log din firebase api");
  console.log(newdata);
  return newdata;
};

const getServiceSchedule = async (serviceMail, dateString) => {
  console.log("getServiceSchedule from api called");
  const docSnap = await getDoc(
    doc(db, "ServiceAccountsDetails", serviceMail, "calendar", dateString)
  );
  var newdata = docSnap.data();

  if (newdata === undefined) {
    var data = {
      8: {},
      9: {},
      10: {},
      11: {},
      12: {},
      13: {},
      14: {},
      15: {},
      16: {},
      17: {},
      18: {},
    };
    setDoc(
      doc(db, "ServiceAccountsDetails", serviceMail, "calendar", dateString),
      data
    )
      .then(() => {
        console.log(
          "date doc added for: " + serviceMail + " date: " + dateString
        );
      })
      .catch((error) => {
        alert(error.message);
      });

    newdata = data;
  }
  return newdata;
};
const getCarDetails = async (carVinNumber) => {
  const q = query(
    collection(db, "Cars"),
    where("vinNumber", "==", carVinNumber)
  );
  var newdata = [];
  const querySnapshot = await getDocs(q);

  for (const doc of querySnapshot.docs) {
    var itemdata = doc.data();
    newdata = [...newdata, itemdata];
  }

  return newdata[0];
};
const db = app.firestore();
const auth = firebase.auth();
const storage = getStorage();

export {
  db,
  auth,
  storage,
  getRequests,
  getRequestOffers,
  getAccountDetails,
  getServiceSchedule,
  getCarDetails,
};
