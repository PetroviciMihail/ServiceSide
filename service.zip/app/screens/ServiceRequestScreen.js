import React, { useEffect, useState } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  Modal,
  TouchableWithoutFeedback,
} from "react-native";
import { useIsFocused } from "@react-navigation/native";
import AppButton from "../components/AppButton";
import AppText from "../components/AppText";
import Screen from "../components/Screen";
import { collection, query, where, getDocs } from "firebase/firestore";
import { getStorage, ref, getDownloadURL } from "firebase/storage";

import colors from "../config/colors";
import { db, auth, storage, getRequests } from "../api/firebase";

import RequestListItem from "../components/lists/RequestListItem";
import { ListItemDeleteAction } from "../components/lists";
import AppTextInput from "../components/AppTextInput";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import PickerItem from "../components/PickerItem";

const categories = [
  {
    backgroundColor: "#fc5c65",
    icon: "floor-lamp",
    label: "Mentenance",
    value: 1,
  },
  {
    backgroundColor: "#fd9644",
    icon: "car",
    label: "Suspension-direction",
    value: 2,
  },
  {
    backgroundColor: "#fed330",
    icon: "camera",
    label: "Wheels",
    value: 3,
  },
  {
    backgroundColor: "#26de81",
    icon: "cards",
    label: "Electronics",
    value: 4,
  },
  {
    backgroundColor: "#2bcbba",
    icon: "shoe-heel",
    label: "Interior",
    value: 5,
  },
];

function ServiceRequestScreen({ navigation }) {
  //const getListingsApi = useApi(listingsApi.getListings);
  const isFocused = useIsFocused();
  const [modalVisible, setModalVisible] = useState(false);
  const [requestsdata, setrequestsData] = useState([]);
  const [distance, setDistance] = useState("3");
  const [category, setCategory] = useState("");
  //console.log("am reincarcat toata faza");
  useEffect(() => {
    console.log("-----------------------------");
    getServiceRequestFromDB();
  }, []);
  useEffect(() => {
    console.log("-----------------------------");
    getServiceRequestFromDB();
  }, [distance, isFocused, category]);

  const getServiceRequestFromDB = async () => {
    const result = await getRequests(
      auth.currentUser.email,
      distance,
      category
    );
    setrequestsData(result);
    console.log(requestsdata);
  };

  return (
    <Screen style={styles.container}>
      <View style={styles.header}>
        <AppText style={styles.title}>
          Service Requests locally, choose radius (in km)
        </AppText>
        <AppTextInput
          width="40%"
          icon="map-marker-radius"
          placeholder={"distance"}
          defaultValue={distance}
          keyboardType="number-pad"
          onChangeText={(text) => {
            setDistance(text);
          }}
        />
      </View>
      <View style={styles.header}>
        <AppText style={styles.title}>Pick a category</AppText>
        <TouchableWithoutFeedback onPress={() => setModalVisible(true)}>
          <View style={styles.picker}>
            {category ? (
              <AppText style={styles.text}>{category}</AppText>
            ) : (
              <AppText style={styles.placeholder}>Pick a category</AppText>
            )}

            <MaterialCommunityIcons
              name="chevron-down"
              size={20}
              color={colors.medium}
            />
          </View>
        </TouchableWithoutFeedback>
        <Modal visible={modalVisible} animationType="slide">
          <Screen>
            <AppButton
              title="Close"
              color={"medium"}
              onPress={() => setModalVisible(false)}
            />
            <FlatList
              data={categories}
              keyExtractor={(item) => item.value.toString()}
              numColumns={1}
              renderItem={({ item }) => (
                <PickerItem
                  label={item.label}
                  onPress={() => {
                    setModalVisible(false);
                    setCategory(item.label);
                  }}
                />
              )}
            />
          </Screen>
        </Modal>
      </View>
      {requestsdata.length ? (
        <View style={{ flex: 1 }}>
          <FlatList
            data={requestsdata}
            keyExtractor={(item) => item.timestamp}
            renderItem={({ item }) => (
              <RequestListItem
                category={"category: " + item.category}
                title={item.carMake + " " + item.carModel + " " + item.carYear}
                image={item.images[0]}
                subTitle={"Current Offers: " + item.offers.length}
                onPress={() => navigation.navigate("Details", item)}
              />
            )}
          />
        </View>
      ) : (
        <AppText style={styles.missingMessage}>
          No service requests locally yet
        </AppText>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.backgroundColor,
  },
  title: {
    fontSize: 18,
    paddingLeft: 25,
    paddingTop: 20,
    color: colors.dark,
    marginBottom: 15,
    width: "60%",
  },
  addbutton: {
    bottom: 10,
  },
  missingMessage: {
    flex: 1,
    textAlign: "center",
    textAlignVertical: "center",
  },
  header: {
    flexDirection: "row",
    width: "100%",
  },
  picker: {
    backgroundColor: colors.light,
    borderRadius: 25,
    flexDirection: "row",
    padding: 15,
    paddingLeft: 25,
    marginRight: 25,
    marginVertical: 5,
  },
});

export default ServiceRequestScreen;
