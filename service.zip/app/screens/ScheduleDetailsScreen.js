import React, { useState, useEffect } from "react";
import { View, StyleSheet, Image } from "react-native";
import AppButton from "../components/AppButton";
import AppTextInput from "../components/AppTextInput";
import Screen from "../components/Screen";
import {
  collection,
  query,
  where,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  doc,
} from "firebase/firestore";
import { ListItem } from "../components/lists";
import CarListItem from "../components/lists/CarListItem";
import AppText from "../components/AppText";
import colors from "../config/colors";
import { db } from "../api/firebase";

function ScheduleDetailsScreen({ route, navigation }) {
  const { appointment, date } = route.params;
  const [loaded, setLoaded] = useState(0);
  const [request, setRequest] = useState({});
  const [finalPrice, setFinalPrice] = useState(0);
  const [odometer, setOdometer] = useState(0);
  //appoitment in client appointments vin+requestTImeAdded de updatat cu km, done sau cancelled
  //detaiile despre request le iau din servicerequests, carvin+requestTimeAdded
  useEffect(() => {
    getDetailsFromDB();
  }, []);

  const getDetailsFromDB = async () => {
    const docSnap = await getDoc(
      doc(
        db,
        "ServiceRequests",
        appointment.carVinNumber + appointment.requestTimeAdded
      )
    );
    setRequest(docSnap.data());
    console.log(docSnap.data());
    setLoaded(1);
  };

  const confirmRequest = () => {
    var docName = request.carVinNumber + request.timeadded;
    var data = {
      done: true,
    };
    updateDoc(doc(db, "ServiceRequests", docName), data)
      .then(() => {
        console.log("Request updated-done");
      })
      .catch((error) => {
        alert(error.message);
      });

    var docName = request.carVinNumber + request.timeadded;
    var data = {
      done: true,
      price: finalPrice,
      km: odometer,
    };
    updateDoc(
      doc(db, "ClientsAccountDetails", request.owner, "appoitments", docName),
      data
    )
      .then(() => {
        console.log("appoitment updated-done");
      })
      .catch((error) => {
        alert(error.message);
      });
    navigation.pop();
  };

  const cancelRequest = () => {
    var docName = request.carVinNumber + request.timeadded;
    var data = {
      canceled: true,
    };
    updateDoc(doc(db, "ServiceRequests", docName), data)
      .then(() => {
        console.log("Request updated-canceled");
      })
      .catch((error) => {
        alert(error.message);
      });

    var data = {
      canceled: true,
    };
    updateDoc(
      doc(db, "ClientsAccountDetails", request.owner, "appoitments", docName),
      data
    )
      .then(() => {
        console.log("appoitment updated-canceled");
      })
      .catch((error) => {
        alert(error.message);
      });
  };

  return (
    <Screen>
      {loaded ? (
        <>
          <ListItem title="Category" subTitle={request.category} />
          <CarListItem
            title={request.carMake + " " + request.carModel}
            subTitle={request.carYear}
            image={request.carImage}
            onPress={() => {
              navigation.navigate("CarDetails", request.carVinNumber);
            }}
          />
          <View style={styles.detailsContainer}>
            <AppText style={styles.detailsTag}>Details</AppText>
            {request.details ? (
              <AppText style={styles.details}>{request.details}</AppText>
            ) : (
              <AppText>no details</AppText>
            )}
          </View>
          {request.images.length ? (
            <View style={styles.imagesContainer}>
              {request.images.map((imageUrl, key) => {
                return (
                  <Image
                    style={styles.image}
                    source={{ uri: imageUrl }}
                    key={key}
                  />
                );
              })}
            </View>
          ) : (
            <AppText style={{ padding: 5, textAlign: "center" }}>
              no images
            </AppText>
          )}
        </>
      ) : null}
      {!request.done ? (
        <>
          <AppTextInput
            icon="gold"
            onChangeText={(text) => setFinalPrice(text)}
            keyboardType="number-pad"
            placeholder="Final price for the visit ($)"
          />
          <AppTextInput
            icon="car-cruise-control"
            onChangeText={(text) => setOdometer(text)}
            keyboardType="number-pad"
            placeholder="Car current odometer (km)"
          />
          <View style={{ flexDirection: "row" }}>
            <AppButton
              title="Cancel"
              color="dark"
              style={{ flex: 0.5, margin: 2 }}
              onPress={() => {
                cancelRequest();
              }}
            />
            <AppButton
              title="Confirm"
              color="secondary"
              style={{ flex: 0.5, margin: 2 }}
              onPress={() => {
                confirmRequest();
              }}
            />
          </View>
        </>
      ) : (
        <AppText style={{ textAlign: "center", margin: 10 }}>
          Allready done
        </AppText>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {},
  detailsTag: {
    marginTop: 5,
    fontSize: 24,
    textAlign: "center",
  },
  detailsContainer: {
    marginTop: 5,
    backgroundColor: colors.white,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    borderRadius: 10,
  },
  image: {
    resizeMode: "contain",
    width: 400,
    height: 400,
    margin: 5,
  },
  imagesContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
});

export default ScheduleDetailsScreen;
