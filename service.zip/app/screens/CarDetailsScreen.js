import React, { useEffect, useState } from "react";
import { View, StyleSheet, Text, Image } from "react-native";
import Screen from "../components/Screen";
import AppText from "../components/AppText";
import { ListItem2 } from "../components/lists";
import { getCarDetails } from "../api/firebase";

function CarDetailsScreen({ route }) {
  const [car, setCar] = useState({});
  const carVinNumber = route.params;
  const [loaded, setLoaded] = useState(0);
  useEffect(() => {
    getCarFromDB();
  }, []);

  const getCarFromDB = async () => {
    const result = await getCarDetails(carVinNumber);
    setCar(result);
    console.log(result);
    setLoaded(1);
  };
  return (
    <Screen>
      {loaded ? (
        <>
          {car.carImageUrl ? (
            <Image style={styles.image} source={{ uri: car.carImageUrl }} />
          ) : null}
          <AppText style={styles.titleTag}>Make</AppText>
          <ListItem2 title={car.make} />
          <AppText style={styles.titleTag}>Model</AppText>
          <ListItem2 title={car.model} />
          <AppText style={styles.titleTag}>Vin Number </AppText>
          <ListItem2 title={car.vinNumber} />
          <AppText style={styles.titleTag}>Year</AppText>
          <ListItem2 title={car.year} />
          <AppText style={styles.titleTag}>Details</AppText>
          <ListItem2 title={car.extraDetails} />
        </>
      ) : (
        <AppText style={{ alignItems: "center", justifyContent: "center" }}>
          Loading...
        </AppText>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {},
  titleTag: {
    paddingTop: 15,
    backgroundColor: "#eef2e1",
    width: "100%",
    padding: 5,
    fontSize: 22,
    textAlign: "center",
  },
  image: {
    resizeMode: "contain",
    width: 400,
    height: 400,
    margin: 5,
  },
  imagesContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
});

export default CarDetailsScreen;
