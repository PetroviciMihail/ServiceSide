import React, { useEffect, useState } from "react";
import { View, StyleSheet, Text, ScrollView } from "react-native";
import { Calendar, CalendarList, Agenda } from "react-native-calendars";
import { auth, getServiceSchedule } from "../api/firebase";
import AppText from "../components/AppText";
import { useNavigation } from "@react-navigation/native";
import HourListItem from "../components/lists/HourListItem";
import Constants from "expo-constants";
import {
  collection,
  query,
  where,
  getDocs,
  getDoc,
  setDoc,
  doc,
  updateDoc,
} from "firebase/firestore";
import { db } from "../api/firebase";
import Screen from "../components/Screen";
import colors from "../config/colors";
function MyScheduleScreen(params) {
  const navigation = useNavigation();
  const [dateSelected, setDateSelected] = useState();
  const [schedule, setSchedule] = useState();
  const [loaded, setLoaded] = useState(0);
  useEffect(() => {
    getServiceScheduleFromDB();
  }, [dateSelected]);
  const getServiceScheduleFromDB = async () => {
    const result = await getServiceSchedule(
      auth.currentUser.email,
      dateSelected
    );
    console.log(result);
    setSchedule(result);
    setLoaded(1);
  };

  return (
    <View style={styles.container}>
      <Calendar
        // Minimum date that can be selected, dates before minDate will be grayed out. Default = undefined

        // Handler which gets executed on day press. Default = undefined
        onDayPress={(day) => {
          var date = new Date(day.dateString);
          if (date.getDay() != 0 && date.getDay() != 6) {
            setLoaded(0);
            setDateSelected(day.dateString);
            console.log(day);
            console.log("selected day", day);
          }
        }}
        hideExtraDays={true}
        // Month format in calendar title. Formatting values: http://arshaw.com/xdate/#Formatting
        monthFormat={"yyyy MM"}
        // Handler which gets executed when visible month changes in calendar. Default = undefined
        onMonthChange={(month) => {
          console.log("month changed", month);
        }}
        // If firstDay=1 week starts from Monday. Note that dayNames and dayNamesShort should still start from Sunday
        firstDay={1}
        // Handler which gets executed when press arrow icon left. It receive a callback can go back month
        onPressArrowLeft={(subtractMonth) => subtractMonth()}
        // Handler which gets executed when press arrow icon right. It receive a callback can go next month
        onPressArrowRight={(addMonth) => addMonth()}
        // Disable all touch events for disabled days. can be override with disableTouchEvent in markedDates
        disableAllTouchEventsForDisabledDays={true}
        // Enable the option to swipe between months. Default = false
        enableSwipeMonths={true}
      />
      {dateSelected && loaded ? (
        <ScrollView
          contentContainerStyle={{
            alignItems: "center",
            marginBottom: 15,
            marginTop: 15,
          }}
        >
          <HourListItem
            schedule={schedule}
            hour={"8"}
            onPress={() => {
              if (schedule["8"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["8"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"9"}
            onPress={() => {
              if (schedule["9"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["9"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"10"}
            onPress={() => {
              if (schedule["10"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["10"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"11"}
            onPress={() => {
              if (schedule["11"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["11"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"12"}
            onPress={() => {
              if (schedule["12"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["12"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"13"}
            onPress={() => {
              if (schedule["13"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["13"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"14"}
            onPress={() => {
              if (schedule["14"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["14"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"15"}
            onPress={() => {
              if (schedule["15"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["15"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"16"}
            onPress={() => {
              if (schedule["16"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["16"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"17"}
            onPress={() => {
              if (schedule["17"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["17"],
                  date: dateSelected,
                });
            }}
          />
          <HourListItem
            schedule={schedule}
            hour={"18"}
            onPress={() => {
              if (schedule["18"].reserved === "reserved")
                navigation.navigate("Details", {
                  appointment: schedule["18"],
                  date: dateSelected,
                });
            }}
          />
        </ScrollView>
      ) : (
        <AppText style={{ textAlign: "center", marginTop: 40 }}>
          select a date to show hourly schedule
        </AppText>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: Constants.statusBarHeight,
    backgroundColor: colors.backgroundColor,
    padding: 5,
    flex: 1,
  },
});

export default MyScheduleScreen;
