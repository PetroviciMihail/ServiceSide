import React from "react";
import { View, StyleSheet } from "react-native";
import { TouchableWithoutFeedback } from "react-native-gesture-handler";
import colors from "../../config/colors";
import AppText from "../AppText";
function HourListItem({ schedule, hour, onPress }) {
  return (
    <View
      style={{
        backgroundColor:
          schedule[hour].reserved === "reserved"
            ? "orange"
            : colors.brigthGreen,
        width: "90%",
        margin: 2,
        padding: 15,
        borderColor: colors.medium,
        borderWidth: 3,
      }}
    >
      <TouchableWithoutFeedback onPress={onPress}>
        <AppText>
          {hour}:00{" "}
          {schedule[hour].reserved === "reserved"
            ? "Reserved (tap to see details) "
            : "Free (tap to add your clients)"}
        </AppText>
      </TouchableWithoutFeedback>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {},
});

export default HourListItem;
